var Dispatcher = require('flux').Dispatcher;

var appDispatcher = new Dispatcher();

module.exports = appDispatcher;
