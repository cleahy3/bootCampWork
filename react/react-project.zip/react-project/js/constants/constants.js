module.exports = {
  HOME_ACTION : "onClickHome",
  LOGIN_ACTION : "onClickLogin",
  SUBMIT_CLICKED: "onClickSubmit",
  END_ACTION: "onEndSubmit"
}
