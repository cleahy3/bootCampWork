var GameArea = React.createClass ({
  render: function(){
    return (
      <div>
        <h1>Game Area</h1>
        <span id="poker-table" />
      </div>
    )
  }
})

module.exports = GameArea;
